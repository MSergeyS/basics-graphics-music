  module shift_register #(
    parameter integer NUNDIGIT = 4
)
(
    input        clk,
    input        rst,
	 input        ena,

    // A dynamic seven-segment display

    output logic [NUNDIGIT-1:0] digit
);


    // сдвиговый регистр (гоняем единичку по кольцу)
    // 0001 -> 0010 -> 0100 -> 1000 -> 0001 -> ...
    // определяет какой из четырёх СИИ светится
    logic [NUNDIGIT-1:0] shift_reg;

    always_ff @ (posedge clk or posedge rst)
      if (rst)
        shift_reg <= NUNDIGIT'(1);
      else if (ena)
        shift_reg <= { shift_reg [0], shift_reg [NUNDIGIT-1:1] };

    assign digit = NUNDIGIT'(shift_reg);
	 
endmodule
