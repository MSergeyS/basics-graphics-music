module mux #(
    parameter integer WIDTH = 4,
	 parameter integer NUNDIGIT = 4
)
(
	 input [WIDTH-1:0] address_in,
	 input [NUNDIGIT-1:0] digit,
    output logic [WIDTH-1:0] address_out
);
	 
	 // индексы элементов в массиве word
    always_comb
      case (4' (digit)) // в зависимости от того, какой из четырёх СИИ светится
          // мы будем менять графику (выбираем нужный симол из массива word)
          4'b1000: address_out = address_in;
          4'b0100: address_out = address_in + 4'd1;
          4'b0010: address_out = address_in + 4'd2;
          4'b0001: address_out = address_in + 4'd3;
          default: address_out = address_in;
      endcase
endmodule
