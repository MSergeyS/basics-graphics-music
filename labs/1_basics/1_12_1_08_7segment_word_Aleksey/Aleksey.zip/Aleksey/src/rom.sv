module rom #(
    parameter integer WIDTH = 4
)
(
	 input [WIDTH-1:0] address,
    output logic [7:0] letter
);

//------------------------------------------------------------------------

    // делаем свой тип данных, называем его seven_seg_encoding_e
    // он представляет собой 8 битный массив
    // далее, используя его, можем не писать  код из 8 бит типа "8'b0001_1100",
    // а можем написать просто "L" (графика символа L на ССИ)
    //   --a--
    //  |     |
    //  f     b
    //  |     |
    //   --g--
    //  |     |
    //  e     c
    //  |     |
    //   --d--  h
    typedef enum bit [7:0]
    {
        L     = 8'b0001_1100,
        zero  = 8'b1111_1100,
        one   = 8'b0110_0000,
        two   = 8'b1101_1010,
        space = 8'b0000_0000
    }
    seven_seg_encoding_e;

    //--------------------------------------------------------------------------

    // задаём массив из 10 элементов типа seven_seg_encoding_e
    // это наше слово, которое будет бегать в бегуще строке
    seven_seg_encoding_e word[10];
    // "    22L102" - будет бегать это слово (здесь мы его задаём)
    assign word[0] = space;
    assign word[1] = space;
    assign word[2] = space;
    assign word[3] = space;
    assign word[4] = two;
    assign word[5] = two;
    assign word[6] = L;
    assign word[7] = one;
    assign word[8] = zero;
    assign word[9] = two;
	 
	 assign letter = word[address];
endmodule