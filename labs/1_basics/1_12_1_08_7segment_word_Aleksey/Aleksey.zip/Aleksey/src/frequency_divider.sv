module frequency_divider #(
    parameter integer BLINKPERIOD = 17,
    parameter integer SPEEDRUNLINE = 25
)
(
    input        clk,
    input        rst,

    // A dynamic seven-segment display

    output logic enable_shift_rg,
    output logic [3:0] addres
);

//------------------------------------------------------------------------

    logic [31:0] cnt;  // счётчик (делитель частоты)
    wire restart;      // управление сдвиговым регистром (переключаем индикатор - один из 4)
    wire enable;       // управляем символом (сегментами ССИ)

    always_ff @ (posedge clk)
        if (rst || restart) // сбрасываем счётчик по rst
		      // ИЛИ сбрасываем счётчик, когда вывели последовательно 10 символов в "слове"
            cnt <= '0;
        else
            cnt <= cnt + 1'd1;

    assign enable_shift_rg = (cnt [BLINKPERIOD-1:0] == '0);
	 assign addres[3:0] = cnt [SPEEDRUNLINE+3:SPEEDRUNLINE]; 
    assign restart = (cnt [SPEEDRUNLINE+3:SPEEDRUNLINE] == 'd10);

    //------------------------------------------------------------------------
	 
	 endmodule